import React from 'react'
import { Link } from 'react-router-dom'

const Header = () => {
  return (
   <>
<header>
    <div className=' header-block position-fixed'>
        <div className=' d-flex justify-content-between align-items-center px-3' style={{height:"80px"}}>
            <div>
                <h3 className=' text-white text-uppercase '>Products</h3>
            </div>
            <div className='user-details gap-4 '>
                <span>
                    <Link to="/register" className='text-white'>Register</Link>
                </span>
                <span>
                    <Link to="/blog" className=' text-white '>Blog</Link>
                </span>
            </div>
        </div>
    </div>
</header>
   </>
  )
}

export default Header