import React, { useEffect, useState } from 'react'
import { Col, FormControl, Row } from 'react-bootstrap'

const DalayInput = () => {

const [inputval, setInpuval] = useState('')
const [typingtimeout, setTypingTimeout]= useState(null)

const handleInput = (e) => {
    const newValue = e.target.value
    if(typingtimeout){
        clearTimeout(typingtimeout)
    }

    const newTimeout = setTimeout(()=>{
        setInpuval(newValue)
    },1000)
setTypingTimeout(newTimeout)
console.log(newValue)
}

useEffect(()=>{
    
})

  return (
   <>
    <Row>
        <Col lg={4}>
            <FormControl type='text' value={inputval} onChange={handleInput} placeholder='type something here' />
        </Col>
    </Row>
   </>
  )
}

export default DalayInput