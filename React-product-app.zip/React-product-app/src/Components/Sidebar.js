import React from 'react'
import { Link, Outlet } from 'react-router-dom'

const Sidebar = () => {
  return (
    <>
   <div className='position-fixed h-100 side-bar'>
       <ul className=' navbar-nav me-auto '>
           <li className=' nav-item '>
              <Link className='nav-link text-white ' to="/dashboard">
                 Dashboard
              </Link>
           </li>
           <li className=' nav-item '>
              <Link className='nav-link text-white ' to="/products">
                 Products
              </Link>
           </li>
           <li className=' nav-item '>
              <Link className='nav-link text-white ' to="/usersposrs">
               usersposrs
              </Link>
           </li>

           <li className=' nav-item '>
              <Link className='nav-link text-white ' to="/reactforms">
                 React Forms
              </Link>
           </li>
           <li className=' nav-item '>
              <Link className='nav-link text-white ' to="/tablepagenation">
              Tablepagenation
              </Link>
           </li>
           <li className=' nav-item '>
              <Link className='nav-link text-white ' to="/delayinput">
              Delay Input
              </Link>
           </li>
       </ul>
   </div>
   <div className='content-col'>
        <Outlet/>
   </div>
   </>
  )
}

export default Sidebar