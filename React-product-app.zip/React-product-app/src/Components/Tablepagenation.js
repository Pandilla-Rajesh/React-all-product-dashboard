import React from 'react'

const Tablepagenation = () => {
  return (
    <div>Tablepagenation</div>
  )
}

export default Tablepagenation