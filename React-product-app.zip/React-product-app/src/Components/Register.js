import React from 'react'
import Header from './Header'

const Register = () => {
  return (
    <>
    <Header/>
    <div>Register</div>
    </>
  )
}

export default Register