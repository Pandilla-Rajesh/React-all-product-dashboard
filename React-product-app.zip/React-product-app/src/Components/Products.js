import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Col, FormSelect, Row, Form, FormControl } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'

const Products = () => {
  const [productlist, setProductlist] = useState()
  const [catlist, setCatlist] = useState()
  const [catval, setCatval] = useState()
  const [filtered, setFiltered] = useState([]) // Initialize filtered state as an empty array
  const [searchInput, setSearchInput] = useState('') // State for search input

  const getProducts = async () =>{
    try{
      const result = await axios.get('https://dummyjson.com/products')
      setProductlist(result.data.products);
      setFiltered(result.data.products)
    }catch(err){
      console.log(err)
    }
  }

  useEffect(()=>{
    getProducts()
  }, [])

  const getCatList = async () =>{
    try{
      const res = await axios.get('https://dummyjson.com/products/categories')
      setCatlist(res.data)
    }catch(err){
      console.log(err)
    }
  }

  const handleSelect = (e) =>{
    setCatval(e.target.value)
    filterProducts(e.target.value, searchInput)
  }

  const handleSearchInput = (e) => {
    setSearchInput(e.target.value)
    if(e.target.value === ""){
      setSearchInput=""
      filterProducts(catval, "")
    }else{
      filterProducts(catval, e.target.value)
    }    
  }

  const filterProducts = (category, search) => {
    if (!category && !search) {
      setFiltered(productlist)
      return
    }

    let filteredProducts = productlist.filter(product => {
      const matchCategory = !category || product.category === category
      const matchSearch = !search || product.title.toLowerCase().includes(search.toLowerCase())
      return matchCategory && matchSearch
    })

    setFiltered(filteredProducts)
  }

  useEffect(()=>{
    getCatList()
  }, [])

  const navigate = useNavigate();
  // const goToPage = (id) =>{
  //   navigate(`/productslist/${id}`)
  // }

const goToPage = (id) =>{
  navigate(`/productslist/${id}`)
}
  
  return (
    <>
    <Row>
      <div className=' d-flex justify-content-end gap-4  '>
        <Col lg={4}>
          <Form.Select name="" value={catval} onChange={handleSelect}>
            <option value={""}>Select Product Category</option>
            {catlist?.map((cat, index)=>{
              return <option key={index} value={cat}>{cat}</option>
            })}
          </Form.Select>
        </Col>
        <Col lg={4}>
          <FormControl type='text' name='' placeholder='search product' onChange={handleSearchInput} />
        </Col>
      </div>

      {filtered ?.length ? filtered?.map((pro, index) =>( 
      <Col lg={4} key={index}>
          <div className="card my-3" >
            <div style={{height:'300px', overflow:'hidden'}}>
               <img src={pro.thumbnail} className="img-fluid" alt="..." />
            </div>
            <div className="card-body">
              <h2 className="card-title">{pro.rating}</h2>
              <h2 className="card-text fw-bold ">{pro.title}</h2>
              <p className="card-text fw-bold ">{pro.price}</p>
              <p className='card-text'>{pro.description}</p>
              <button className="btn btn-success " onClick={()=>goToPage(pro.id)}>Go to Product</button>
            </div>
          </div>
        </Col>
        )
      ):(
        <div className='text-center'>
           <h1 className=' text-danger '>No Records Found</h1>
        </div>
      )}
    
    </Row>
    </>
  )
}

export default Products 
