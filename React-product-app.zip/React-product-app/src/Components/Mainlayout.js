import React from 'react'
import Sidebar from './Sidebar'
import { Outlet } from 'react-router-dom'
import Header from './Header'

const Mainlayout = () => {
  return (
    <div className='auth-main'>
    <div>
        <Header/>
    </div>
    <div>
        <Sidebar/>
    </div>
    {/* <div>
        <Outlet/>
    </div> */}
    </div>
  )
}

export default Mainlayout