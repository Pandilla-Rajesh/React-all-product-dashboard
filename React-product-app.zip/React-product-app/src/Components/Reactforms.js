import React, { useState } from 'react'
import { Col, FormControl, Row } from 'react-bootstrap'

const Reactforms = () => {

  const [inputval, setInputval] = useState('')
  const [typingtimeout, setTypingTimeout] = useState(null)

  const handleInput = (e) => {
    const newValue = e.target.value
    if(typingtimeout){
      clearTimeout(typingtimeout)
    }
    const newTimeout = setTimeout(()=>{
      setInputval(newValue)
    }, 1000)
    setTypingTimeout(newTimeout)
    // setInputval(e.target.value)
    console.log(newValue, "typing");
  }


  return (
   <>
    <Row>
      <Col xxl={12}>
        <h1>Input time text event</h1>
      </Col>
      <Col xxl={4}>
         <FormControl type='text' value={inputval} onChange={handleInput} placeholder='type something...' />
      </Col>
    </Row>
   </>
  )
}

export default Reactforms