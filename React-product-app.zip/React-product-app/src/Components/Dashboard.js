import React, { useEffect } from "react";
import { Card, Col, Row } from "react-bootstrap";

const Dashboard = () => {

async function getCountrysdata (){
  const response = await fetch('https://restcountries.com/v2/all')
  const countryData = await response.json()
  console.log(response)
  return countryData
 
}

useEffect(()=>{
  getCountrysdata()
}, [])

getCountrysdata()

  return (
    <Row>
      <Col lg={4}>
        <div className="card">
          <div className="card-img">
            <img
              src={require("../images/card-image.jpg")}
              className="img-fluid"
            />
          </div>
          <div className="card-box box-1">
            <h3>What is Lorem Ipsum</h3>
            <p>Lorem Ipsum is simply dummy text of the printing</p>
          </div>
          <div className="card-box box-2">
            <h4>Where can I get some</h4>
            <p>
              There are many variations of passages of Lorem Ipsum available
            </p>
          </div>
        </div>
      </Col>
      <Col lg={12}>
        <div className="grid-container">
          {/* grid column-gap */}
          <div className="item1">
            The column-gap property sets the gap between the columns
          </div>
          <div className="item1">
            The column-gap property sets the gap between the columns
          </div>
          <div className="item1">
            The column-gap property sets the gap between the columns
          </div>
          <div className="item1">
            The column-gap property sets the gap between the columns
          </div>
          <div className="item1">
            The column-gap property sets the gap between the columns
          </div>
          <div className="item1">
            The column-gap property sets the gap between the columns
          </div>
        </div>
      </Col>

      {/* column-gap */}
      <Col lg={12}>
        <div class="grid-con">
          <div className="item1">1</div>
          <div className="item2">2</div>
          <div className="item3">3</div>
          <div className="item4">4</div>
          <div className="item5">5</div>
          <div className="item6">6</div>
          <div className="item7">7</div>
          <div className="item8">8</div>
        </div>
      </Col>

      <Col lg={12}>
          <div className="grid-cl">
            <div className="gr">Why do we use it</div>
            <div className="gr">Why do we use it</div>
            <div className="gr">Why do we use it</div>
            <div className="gr">Why do we use it</div>
            <div className="gr">Why do we use it</div>
            <div className="gr">Why do we use it</div>
          </div>
      </Col>

    </Row>
  );
};

export default Dashboard;
