import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button, Col, Row } from "react-bootstrap";
import { useParams } from "react-router-dom";

const Productslist = () => {
  const [count, setCount] = useState(0);
  const handleCount = () => {
    setCount((count) => count + 1);
  };

  let { id } = useParams();
  const [productlist, setProductlist] = useState();
  const getProducts = async () => {
    try {
      const result = await axios.get(`https://dummyjson.com/products/${id}`);
      console.log(result, "line15");
      setProductlist(result.data);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    getProducts();
  }, []);

  return (
    <div className=" bg-white p-5">
      <Row>
        <Col lg={4}>
          <div className="card my-3">
            <div style={{ height: "300px", overflow: "hidden" }}>
              <img
                src={productlist?.thumbnail}
                className="img-fluid"
                alt="..."
              />
            </div>
            <div className="card-body">
              <h2 className="card-title">{productlist?.rating}</h2>
              <h2 className="card-text fw-bold ">{productlist?.title}</h2>
              <p className="card-text fw-bold ">{productlist?.price}</p>
              <p className="card-text">{productlist?.description}</p>
            </div>
          </div>
        </Col>

        <Col>
          <h6>{count}</h6>
          <Button onMouseOver={handleCount}>MouseHover</Button>
        </Col>
      </Row>

      <div className=" d-flex justify-content-between my-2 bg-dark-subtle ">
        <div>1</div>
        <div>2</div>
        <div>3</div>
      </div>
      <div style={{background:'red'}}>1</div>
    </div>
  );
};

export default Productslist;
