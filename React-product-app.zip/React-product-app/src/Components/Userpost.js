import React, { useState, useEffect } from 'react'
import { Form } from 'react-bootstrap';

const Userpost = () => {
    
  const [inputval, setInputval] = useState('posts')
  const [list, setList] = useState()

  const handleChange = (e) =>{
    setInputval(e.target.value)
  }

  useEffect(()=>{
    fetch(`https://jsonplaceholder.typicode.com/${inputval}`).then(res=>res.json())
    .then(data =>setList(data))
  }, [inputval])

  console.log(inputval)


    return ( 
  
      <> 
        <div className=' d-flex '>
            <div className=' d-flex align-items-center  '>
                <Form.Check type='radio' value="posts" className='mt-0' onChange={handleChange} checked={inputval == 'posts'} />
                <h6 className='ms-2'>Posts</h6>
            </div>
            
            <div className=' d-flex align-items-center  '>
                <Form.Check type='radio' value="users" className='m-0' onChange={handleChange} checked={inputval == 'users'} />
                <h6 className='ms-2'>Users</h6>
            </div> 
        </div>

        <div>
            {list?.map((el)=>{
                return (
                    <h5>{el.title || el.email}</h5>
                )
            })}
        </div>

      </> 
  
    ) 
}

export default Userpost