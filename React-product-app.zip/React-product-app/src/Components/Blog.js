import React, { useState } from 'react'
import Header from './Header'

const Blog = () => {

const [count, setCount] = useState(0)

function increment(){
  // setCount(prevCount => prevCount+=1)
  setCount(function(prevCount){
    return prevCount += 1
  })
}

function decrement(){

  setCount(function(prevCount){
    if(prevCount < 0){
      return prevCount <= 1
    }else{
      return (prevCount =0)
    }
  })
}


let [num, setNum]= useState(0);

let incNum =()=>{

  if(num => num <= 0){
    setNum(num += 1)
  }
};

let decNum = () => {
   if(num >+ 0)
   {
    setNum(num - 1);
   }
}

let handleChange = (e)=>{
 setNum(e.target.value);
}

  return (
    <>
    <Header/>
    <div>
      <h1>{count}</h1>
      <button className=' btn btn-dark ' onClick={increment}>Increment</button>
      <button className=' btn btn-info ' onClick={decrement}>Decrement</button>
    </div>


    <div className="col-xl-1">
    <div class="input-group">
  <div class="input-group-prepend">
    <button class="btn btn-outline-primary" type="button" onClick={decNum}>-</button>
  </div>
  <input type="text" class="form-control" value={num} onChange={handleChange}/>
  <div class="input-group-prepend">
    <button class="btn btn-outline-primary" type="button" onClick={incNum}>+</button>
  </div>
</div>
</div>

    </>
  )
}

export default Blog