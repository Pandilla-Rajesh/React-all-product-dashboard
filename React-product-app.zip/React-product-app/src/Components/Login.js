import React, { useEffect, useState } from 'react'
import Header from './Header'
import { Col, Container, FormControl, Row, Form, Button} from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { useFormik } from 'formik'
import * as yup from 'yup';


const Login = () => {

const [login, setLogin] = useState({
    username:'',
    password:''
})

const navigate = useNavigate()

const handleChange = (e) =>{
    const {name, value} = e.target
    setLogin({...login, [name]: value})
}

const [error, setErrors] = useState({});
const handleSubmit =  async (e) => {
     // e.preventDefault();
    // if(login.email && login.password) {
    //     setLogin({
    //         email: login.email,
    //         password: login.password
    //     });
    // } else {
    //     alert("Please enter the details");
    // }


    const erros = {}
    if(!login.username.trim()){
        erros.username = "User name is required"
    }
    if(!login.password.trim()){
        erros.password = "Password is required"
    }
    if(Object.keys(erros).length === 0){
        console.log(login, "Form Submited")
    }else{
       setErrors(erros)
    }

    e.preventDefault();
    try{
        const logpayload = {
            username: login.username,
            password: login.password,
        }
        const res = await axios.post('https://dummyjson.com/auth/login', logpayload)
        if(res.status == 200 && res.data){
            alert("login Success");
            navigate('/dashboard')
            console.log(res, "line35")
        }
        window.location.reload()
    }
    catch(err){
        alert("login Failed");
        console.log(err)
    }
}

// const validationSchema = Yup.Object().shape ({
//     username:Yup.string().required('This is Mandatory')
//         .min(5,"Minimum 5 characters required")
//         .max(64,"Maximum allowed characters are 64")
//         .test("valid-description-whitespace","Too many white spaces are not allowed",
//             (value) => {
//               const consecutiveWhiteSpaces = value.match(/\s{2,}/g);
//               return !consecutiveWhiteSpaces;
//             })
//         .matches(EmailRegex,"Only String + '@' Symbol and '.'are allowed"),

//         password: Yup.string().required('This is Mandatory')
//         .min(8,"Minimum 8 characters required")
//         .max(32,"Maximum allowed characters are 32")
// });

// const formik = useFormik({
//     initialValues:{
//         username:'',
//         password:''
//     },
//     onSubmit:handleSubmit,
//     validationSchema:validationSchema
// })

  return (
    <div >

            <Container>
                <Row className='auth-layout'>
                    <Col lg={5}>
                        <div className='login-block text-center '>
                            <h2 >Login</h2>
                            <Form onSubmit={handleSubmit}>
                                <FormControl type='text' name='username' className='mb-3' value={login.username} placeholder='Enter Email' onChange={handleChange}/>
                               <small className=' text-danger'>{error.username}</small>
                                <FormControl type='password' name='password' className='mb-3' value={login.password} placeholder='Enter Password' onChange={handleChange}/>
                                <small className='text-danger'>{error.password}</small>
                                <Button type='submit' className=' w-100'>Submit</Button>
                            </Form>
                        </div>
                    </Col>
                </Row>
            </Container>
    </div>
  )
  }

export default Login