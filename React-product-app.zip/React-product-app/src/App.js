import logo from './logo.svg';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import Mainlayout from './Components/Mainlayout';
import Login from './Components/Login';
import Register from './Components/Register';
import Blog from './Components/Blog';
import Products from './Components/Products';
import Productslist from './Components/Productslist';
import Reactforms from './Components/Reactforms';
import Dashboard from './Components/Dashboard';
import Tablepagenation from './Components/Tablepagenation';
import Userpost from './Components/Userpost';
import DalayInput from './Components/DalayInput';

function App() {
  return (
    <Routes>
      <Route path='/' element={<Login/>}></Route>
      <Route path='/register' element={<Register />} />
      <Route path='/blog' element={<Blog />} />
      <Route path='/' element={<Mainlayout/>}>
          <Route path='/dashboard' element={<Dashboard/>}/>
          <Route path='/products' element={<Products />} />
          <Route path='/productslist/' element={<Productslist/>}/>
          <Route path='/productslist/:id' element={<Productslist/>}/>
          <Route path='/reactforms' element={<Reactforms />}/>
          <Route path='/usersposrs' element={<Userpost />}/>
          <Route path='/tablepagenation' element={<Tablepagenation/>}/>
          <Route path='/delayinput' element={<DalayInput/>}/>
      </Route>
    </Routes>
  );
}

export default App;
