import React from 'react';

const reducers = () => {
  return (
    <div>
      
    </div>
  );
}

export default reducers;
